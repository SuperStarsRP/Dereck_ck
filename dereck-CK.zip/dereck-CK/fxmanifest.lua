-- DISCORD A-C SHOP https://discord.gg/qyyVjKCYFr
fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'DERECK from Super Shop'
description 'Hacer ck a otros jugadores por medio de comando'
version '1.0.0'


server_scripts {
    '@oxmysql/lib/MySQL.lua',
    '@es_extended/locale.lua',
    'server/server.lua',
}

client_scripts {
    'client/client.lua',
}

dependencies {
    'es_extended',
    'ox_inventory'
}

---By Dereck---
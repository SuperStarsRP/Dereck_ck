ESX = exports["es_extended"]:getSharedObject()

RegisterCommand('ck', function(source, args, rawCommand)
    local xAdmin = ESX.GetPlayerFromId(source)
    if xAdmin.getGroup() ~= 'admin' and xAdmin.getGroup() ~= 'superadmin' then
        TriggerClientEvent('chat:addMessage', source, { args = { '^1SYSTEM', 'No tienes permisos para usar este comando.' } })
        return
    end

    local targetId = tonumber(args[1])
    if not targetId then
        TriggerClientEvent('chat:addMessage', source, { args = { '^1SYSTEM', 'Debes proporcionar una ID válida de jugador.' } })
        return
    end
print("##########^3Creado por Dereck###########")
    local xPlayer = ESX.GetPlayerFromId(targetId)
    if xPlayer then

        exports.ox_inventory:ClearInventory(targetId)

        MySQL.Async.execute('DELETE FROM owned_vehicles WHERE owner = @owner', {
            ['@owner'] = xPlayer.identifier
        })
        MySQL.Async.execute('DELETE FROM owned_vehicles WHERE owner = @owner', {
            ['@owner'] = xPlayer.identifier
        })
        print("###########^3UNETE AL DISCORD  https://discord.gg/N3tYyNTPMJ  #########" ) 
        xPlayer.setAccountMoney('money', 0)
        xPlayer.setAccountMoney('bank', 0)
        xPlayer.setAccountMoney('black_money', 0)

        MySQL.Async.execute('DELETE FROM user_licenses WHERE owner = @owner', {
            ['@owner'] = xPlayer.identifier
        })

        MySQL.Async.execute('DELETE FROM users WHERE identifier = @identifier', {
            ['@identifier'] = xPlayer.identifier
        })


        DropPlayer(targetId, 'Te han hecho ck. Debes crear un nuevo personaje.')

        TriggerClientEvent('chat:addMessage', source, { args = { '^2SYSTEM', 'El jugador ha sido reseteado, sus datos han sido eliminados, y ha sido expulsado correctamente.' } })
    else
        TriggerClientEvent('chat:addMessage', source, { args = { '^1SYSTEM', 'No se encontró al jugador con la ID proporcionada.' } })
    end
end, true)
